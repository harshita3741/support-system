import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';

type DoctorKey = 'cardio' | 'neuro' | 'ortho' | 'general';
type PriorityLevel = 'HIGH' | 'MEDIUM' | 'LOW';

type PatientRow = {
  id: string;
  name: string;
  initials: string;
  caseId: string;
  priority: PriorityLevel | string;
  startDate: string;
  endDate: string;
  age: number;
  gender: string;
  reason: string;
};

type AppointmentItem = {
  id: number;
  patientId: string;
  patientName: string;
  time: string;
  note: string;
  color: string;
  status: 'scheduled' | 'pending' | 'completed' | 'cancelled';
  date: string;
};

type ScheduleBlock = {
  id: number;
  patientId: string;
  patientName: string;
  time: string;
  note: string;
  left: string;
  width: string;
  bg: string;
  color: string;
  date: string;
};

type CalendarDay = {
  date: number | null;
  isToday: boolean;
  isSelected: boolean;
  hasAppointment: boolean;
  isPending: boolean;
};

type IncomingCallPatient = {
  id: string;
  name: string;
  reason: string;
  time: string;
  avatar: string;
};

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './dashboard.html',
  styleUrls: ['./dashboard.css']
})
export class Dashboard implements OnInit {
  doctorKey: DoctorKey = 'cardio';
  doctorName = 'Dr. Smith';
  doctorDepartment = 'CARDIO';

  greeting = 'Good Morning';
  isLoading = false;

  patientRows: PatientRow[] = [];
  allAppointments: AppointmentItem[] = [];
  allScheduleBlocks: ScheduleBlock[] = [];

  todayAppointments: AppointmentItem[] = [];
  todaySchedule: ScheduleBlock[] = [];

  private readonly today = new Date();

  calendarViewYear = this.today.getFullYear();
  calendarViewMonth = this.today.getMonth();
  calendarDays: CalendarDay[] = [];
  selectedDate = this.toYMD(this.today);

  sortAsc = true;

  showIncomingCallPopup = true;
  incomingCallPatient: IncomingCallPatient = {
    id: 'C-1042',
    name: 'Priya Mehta',
    reason: 'Follow-up consultation',
    time: 'Incoming now',
    avatar: 'PM'
  };

  get calendarMonth(): string {
    const names = [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ];
    return `${names[this.calendarViewMonth]} ${this.calendarViewYear}`;
  }

  doctorSeedData: Record<DoctorKey, {
    doctorName: string;
    department: string;
    patients: PatientRow[];
    appointments: AppointmentItem[];
    scheduleBlocks: ScheduleBlock[];
  }> = {
    cardio: {
      doctorName: 'Dr. Smith',
      department: 'CARDIO',
      patients: [
        { id: 'C-1042', name: 'Priya Mehta', initials: 'PM', caseId: 'CASE-1001', priority: 'MEDIUM', startDate: 'Today', endDate: '—', age: 52, gender: 'Female', reason: 'Cardiac follow-up' },
        { id: 'C-1043', name: 'Rohan Verma', initials: 'RV', caseId: 'CASE-1002', priority: 'MEDIUM', startDate: 'Today', endDate: '—', age: 48, gender: 'Male', reason: 'Post-op check' }
      ],
      appointments: [
        { id: 1, patientId: 'C-1042', patientName: 'Priya Mehta', time: '09:00 AM', note: 'Follow-up consultation', color: '#3b82f6', status: 'scheduled', date: '2026-04-16' },
        { id: 2, patientId: 'C-1043', patientName: 'Rohan Verma', time: '02:30 PM', note: 'Post-op check', color: '#2563eb', status: 'pending', date: '2026-04-16' },
        { id: 3, patientId: 'C-1042', patientName: 'Priya Mehta', time: '11:00 AM', note: 'ECG review', color: '#3b82f6', status: 'scheduled', date: '2026-04-19' },
        { id: 4, patientId: 'C-1043', patientName: 'Rohan Verma', time: '03:00 PM', note: 'Medication review', color: '#2563eb', status: 'pending', date: '2026-04-23' },
        { id: 5, patientId: 'C-1042', patientName: 'Priya Mehta', time: '10:00 AM', note: 'Final discharge check', color: '#3b82f6', status: 'scheduled', date: '2026-05-05' }
      ],
      scheduleBlocks: [
        { id: 1, patientId: 'C-1042', patientName: 'Priya Mehta', time: '09:00 AM', note: 'Follow-up consultation', left: '11%', width: '14%', bg: '#dbeafe', color: '#1d4ed8', date: '2026-04-16' },
        { id: 2, patientId: 'C-1043', patientName: 'Rohan Verma', time: '02:30 PM', note: 'Post-op check', left: '66%', width: '13%', bg: '#dbeafe', color: '#1d4ed8', date: '2026-04-16' },
        { id: 3, patientId: 'C-1042', patientName: 'Priya Mehta', time: '11:00 AM', note: 'ECG review', left: '30%', width: '14%', bg: '#dbeafe', color: '#1d4ed8', date: '2026-04-19' },
        { id: 4, patientId: 'C-1043', patientName: 'Rohan Verma', time: '03:00 PM', note: 'Medication review', left: '70%', width: '13%', bg: '#dbeafe', color: '#1d4ed8', date: '2026-04-23' },
        { id: 5, patientId: 'C-1042', patientName: 'Priya Mehta', time: '10:00 AM', note: 'Final discharge check', left: '20%', width: '14%', bg: '#dbeafe', color: '#1d4ed8', date: '2026-05-05' }
      ]
    },

    neuro: {
      doctorName: 'Dr. Adams',
      department: 'NEURO',
      patients: [
        { id: 'N-2011', name: 'Amit Sharma', initials: 'AS', caseId: 'CASE-2001', priority: 'HIGH', startDate: 'Today', endDate: '—', age: 45, gender: 'Male', reason: 'Migraine review' },
        { id: 'N-2012', name: 'Neha Sharma', initials: 'NS', caseId: 'CASE-2002', priority: 'MEDIUM', startDate: 'Today', endDate: '—', age: 39, gender: 'Female', reason: 'MRI review' }
      ],
      appointments: [
        { id: 10, patientId: 'N-2011', patientName: 'Amit Sharma', time: '10:00 AM', note: 'Migraine consultation', color: '#8b5cf6', status: 'scheduled', date: '2026-04-17' },
        { id: 11, patientId: 'N-2012', patientName: 'Neha Sharma', time: '11:30 AM', note: 'MRI review', color: '#f59e0b', status: 'pending', date: '2026-04-17' },
        { id: 12, patientId: 'N-2011', patientName: 'Amit Sharma', time: '09:00 AM', note: 'EEG scan follow-up', color: '#8b5cf6', status: 'scheduled', date: '2026-04-22' },
        { id: 13, patientId: 'N-2012', patientName: 'Neha Sharma', time: '02:00 PM', note: 'Neuro assessment', color: '#f59e0b', status: 'completed', date: '2026-04-14' }
      ],
      scheduleBlocks: [
        { id: 10, patientId: 'N-2011', patientName: 'Amit Sharma', time: '10:00 AM', note: 'Migraine consultation', left: '20%', width: '13%', bg: '#ede9fe', color: '#6d28d9', date: '2026-04-17' },
        { id: 11, patientId: 'N-2012', patientName: 'Neha Sharma', time: '11:30 AM', note: 'MRI review', left: '35%', width: '14%', bg: '#fef3c7', color: '#b45309', date: '2026-04-17' },
        { id: 12, patientId: 'N-2011', patientName: 'Amit Sharma', time: '09:00 AM', note: 'EEG scan follow-up', left: '11%', width: '13%', bg: '#ede9fe', color: '#6d28d9', date: '2026-04-22' },
        { id: 13, patientId: 'N-2012', patientName: 'Neha Sharma', time: '02:00 PM', note: 'Neuro assessment', left: '55%', width: '14%', bg: '#fef3c7', color: '#b45309', date: '2026-04-14' }
      ]
    },

    ortho: {
      doctorName: 'Dr. Patel',
      department: 'ORTHO',
      patients: [
        { id: 'O-3001', name: 'Vikram Singh', initials: 'VS', caseId: 'CASE-3001', priority: 'MEDIUM', startDate: 'Today', endDate: '—', age: 56, gender: 'Male', reason: 'Knee pain review' },
        { id: 'O-3002', name: 'Pooja Nair', initials: 'PN', caseId: 'CASE-3002', priority: 'HIGH', startDate: 'Today', endDate: '—', age: 34, gender: 'Female', reason: 'Fracture follow-up' }
      ],
      appointments: [
        { id: 20, patientId: 'O-3001', patientName: 'Vikram Singh', time: '09:30 AM', note: 'Knee pain review', color: '#10b981', status: 'scheduled', date: '2026-04-18' },
        { id: 21, patientId: 'O-3002', patientName: 'Pooja Nair', time: '03:00 PM', note: 'Fracture follow-up', color: '#ef4444', status: 'pending', date: '2026-04-18' },
        { id: 22, patientId: 'O-3001', patientName: 'Vikram Singh', time: '11:00 AM', note: 'Physio assessment', color: '#10b981', status: 'scheduled', date: '2026-04-25' },
        { id: 23, patientId: 'O-3002', patientName: 'Pooja Nair', time: '10:30 AM', note: 'X-ray review', color: '#ef4444', status: 'completed', date: '2026-04-15' }
      ],
      scheduleBlocks: [
        { id: 20, patientId: 'O-3001', patientName: 'Vikram Singh', time: '09:30 AM', note: 'Knee pain review', left: '15%', width: '14%', bg: '#d1fae5', color: '#047857', date: '2026-04-18' },
        { id: 21, patientId: 'O-3002', patientName: 'Pooja Nair', time: '03:00 PM', note: 'Fracture follow-up', left: '70%', width: '13%', bg: '#fee2e2', color: '#b91c1c', date: '2026-04-18' },
        { id: 22, patientId: 'O-3001', patientName: 'Vikram Singh', time: '11:00 AM', note: 'Physio assessment', left: '30%', width: '14%', bg: '#d1fae5', color: '#047857', date: '2026-04-25' },
        { id: 23, patientId: 'O-3002', patientName: 'Pooja Nair', time: '10:30 AM', note: 'X-ray review', left: '22%', width: '13%', bg: '#fee2e2', color: '#b91c1c', date: '2026-04-15' }
      ]
    },

    general: {
      doctorName: 'Dr. Johnson',
      department: 'GENERAL',
      patients: [
        { id: 'G-4001', name: 'Anita Rao', initials: 'AR', caseId: 'CASE-4001', priority: 'MEDIUM', startDate: 'Today', endDate: '—', age: 41, gender: 'Female', reason: 'General consultation' },
        { id: 'G-4002', name: 'Manoj Kumar', initials: 'MK', caseId: 'CASE-4002', priority: 'LOW', startDate: 'Today', endDate: '—', age: 50, gender: 'Male', reason: 'Routine check-up' }
      ],
      appointments: [
        { id: 30, patientId: 'G-4001', patientName: 'Anita Rao', time: '09:30 AM', note: 'General consultation', color: '#14b8a6', status: 'scheduled', date: '2026-04-28' },
        { id: 31, patientId: 'G-4002', patientName: 'Manoj Kumar', time: '11:00 AM', note: 'Routine check-up', color: '#0f766e', status: 'pending', date: '2026-04-28' },
        { id: 32, patientId: 'G-4001', patientName: 'Anita Rao', time: '02:00 PM', note: 'Review vitals', color: '#14b8a6', status: 'completed', date: '2026-04-26' },
        { id: 33, patientId: 'G-4002', patientName: 'Manoj Kumar', time: '03:30 PM', note: 'Prescription follow-up', color: '#0f766e', status: 'scheduled', date: '2026-05-02' }
      ],
      scheduleBlocks: [
        { id: 30, patientId: 'G-4001', patientName: 'Anita Rao', time: '09:30 AM', note: 'General consultation', left: '14%', width: '14%', bg: '#ccfbf1', color: '#0f766e', date: '2026-04-28' },
        { id: 31, patientId: 'G-4002', patientName: 'Manoj Kumar', time: '11:00 AM', note: 'Routine check-up', left: '31%', width: '14%', bg: '#d1fae5', color: '#047857', date: '2026-04-28' },
        { id: 32, patientId: 'G-4001', patientName: 'Anita Rao', time: '02:00 PM', note: 'Review vitals', left: '58%', width: '13%', bg: '#ccfbf1', color: '#0f766e', date: '2026-04-26' },
        { id: 33, patientId: 'G-4002', patientName: 'Manoj Kumar', time: '03:30 PM', note: 'Prescription follow-up', left: '70%', width: '13%', bg: '#d1fae5', color: '#047857', date: '2026-05-02' }
      ]
    }
  };

  constructor(private router: Router) {}

  ngOnInit(): void {
    this.setGreeting();
    this.detectLoggedInDoctor();
    this.loadDoctorDashboardData();
    this.buildCalendarDays();
    this.filterByDate(this.selectedDate);
    this.setIncomingCallPatient();
  }

  private toYMD(date: Date): string {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, '0');
    const d = String(date.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }

  setGreeting(): void {
    const hour = new Date().getHours();
    if (hour < 12) this.greeting = 'Good Morning';
    else if (hour < 17) this.greeting = 'Good Afternoon';
    else this.greeting = 'Good Evening';
  }

  detectLoggedInDoctor(): void {
    const sessionRaw = localStorage.getItem('doctor');
    const session = sessionRaw ? JSON.parse(sessionRaw) : null;

    const storedDept = (session?.dept || '').toLowerCase();

    if (storedDept.includes('neuro')) {
      this.doctorKey = 'neuro';
    } else if (storedDept.includes('ortho')) {
      this.doctorKey = 'ortho';
    } else if (storedDept.includes('general')) {
      this.doctorKey = 'general';
    } else {
      this.doctorKey = 'cardio';
    }
  }

  loadDoctorDashboardData(): void {
    const data = this.doctorSeedData[this.doctorKey];
    const sessionRaw = localStorage.getItem('doctor');
    const session = sessionRaw ? JSON.parse(sessionRaw) : null;

    this.doctorName = session?.name || data.doctorName;
    this.doctorDepartment = session?.dept || data.department;
    this.patientRows = [...data.patients];
    this.allAppointments = [...data.appointments];
    this.allScheduleBlocks = [...data.scheduleBlocks];
    this.isLoading = false;
  }

  setIncomingCallPatient(): void {
    const firstPatient = this.patientRows[0];
    if (!firstPatient) {
      this.showIncomingCallPopup = false;
      return;
    }

    this.incomingCallPatient = {
      id: firstPatient.id,
      name: firstPatient.name,
      reason: firstPatient.reason,
      time: 'Incoming now',
      avatar: firstPatient.initials
    };
  }

  acceptIncomingCall(): void {
    this.showIncomingCallPopup = false;
    this.router.navigate(['/incoming-call', this.incomingCallPatient.id]);
  }

  dismissIncomingCall(): void {
    this.showIncomingCallPopup = false;
  }

  prevMonth(): void {
    if (this.calendarViewMonth === 0) {
      this.calendarViewMonth = 11;
      this.calendarViewYear--;
    } else {
      this.calendarViewMonth--;
    }
    this.buildCalendarDays();
  }

  nextMonth(): void {
    if (this.calendarViewMonth === 11) {
      this.calendarViewMonth = 0;
      this.calendarViewYear++;
    } else {
      this.calendarViewMonth++;
    }
    this.buildCalendarDays();
  }

  buildCalendarDays(): void {
    const year = this.calendarViewYear;
    const month = this.calendarViewMonth;
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    const firstDow = new Date(year, month, 1).getDay();
    const offset = firstDow === 0 ? 6 : firstDow - 1;

    const selectedParts = this.selectedDate.split('-');
    const selYear = parseInt(selectedParts[0], 10);
    const selMonth = parseInt(selectedParts[1], 10) - 1;
    const selDate = parseInt(selectedParts[2], 10);

    const apptDates = new Set<number>();
    const pendingDates = new Set<number>();

    for (const appt of this.allAppointments) {
      const [ay, am, ad] = appt.date.split('-').map(Number);
      if (ay === year && am - 1 === month) {
        if (appt.status === 'pending') pendingDates.add(ad);
        else apptDates.add(ad);
      }
    }

    const days: CalendarDay[] = [];

    for (let i = 0; i < offset; i++) {
      days.push({
        date: null,
        isToday: false,
        isSelected: false,
        hasAppointment: false,
        isPending: false
      });
    }

    for (let d = 1; d <= daysInMonth; d++) {
      days.push({
        date: d,
        isToday: d === this.today.getDate() && month === this.today.getMonth() && year === this.today.getFullYear(),
        isSelected: d === selDate && month === selMonth && year === selYear,
        hasAppointment: apptDates.has(d),
        isPending: pendingDates.has(d)
      });
    }

    this.calendarDays = days;
  }

  selectDate(day: CalendarDay): void {
    if (!day.date) return;
    const m = String(this.calendarViewMonth + 1).padStart(2, '0');
    const d = String(day.date).padStart(2, '0');
    this.selectedDate = `${this.calendarViewYear}-${m}-${d}`;
    this.buildCalendarDays();
    this.filterByDate(this.selectedDate);
  }

  filterByDate(dateStr: string): void {
    this.todayAppointments = this.allAppointments.filter(a => a.date === dateStr);
    this.todaySchedule = this.allScheduleBlocks.filter(b => b.date === dateStr);
  }

  priorityClass(priority: string): 'high' | 'medium' | 'low' {
    const p = (priority || '').toLowerCase();
    if (p.includes('high')) return 'high';
    if (p.includes('low')) return 'low';
    return 'medium';
  }

  openPatient(patientId: string): void {
    if (!patientId) return;
    this.router.navigate(['/monitor', patientId]);
  }

  goToQueue(): void {
    this.router.navigate(['/queue']);
  }

  goToSchedule(): void {
    this.router.navigate(['/schedule']);
  }

  get totalCases(): number {
    return this.patientRows.length;
  }

  get resolvedCases(): number {
    return Math.max(this.patientRows.length - 1, 0);
  }

  get urgentCount(): number {
    return this.patientRows.filter(p => this.priorityClass(p.priority) === 'high').length;
  }

  get avgResponse(): string {
    return 'Live';
  }

  get inQueue(): number {
    return Math.max(this.patientRows.length - 1, 0);
  }

  get sortLabel(): string {
    return this.sortAsc ? 'A–Z' : 'Z–A';
  }

  sortPatients(): void {
    this.sortAsc = !this.sortAsc;
    this.patientRows = [...this.patientRows].sort((a, b) =>
      this.sortAsc ? a.name.localeCompare(b.name) : b.name.localeCompare(a.name)
    );
  }

  get formattedSelectedDate(): string {
    const [y, m, d] = this.selectedDate.split('-');
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return `${months[parseInt(m, 10) - 1]} ${parseInt(d, 10)}, ${y}`;
  }
}